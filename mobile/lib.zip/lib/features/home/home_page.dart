import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/theme/app_theme.dart';
import '../../config/api_config.dart';
import '../auth/auth_controller.dart';
import '../admin/admin_dashboard_page.dart';
import 'catalog_page.dart';
import 'my_orders_page.dart';
import 'edit_profile_dialog.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  int _selectedIndex = 0;

  static const List<BottomNavigationBarItem> _bottomItems = [
    BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Beranda'),
    BottomNavigationBarItem(
      icon: Icon(Icons.receipt_long_rounded),
      label: 'Pesanan',
    ),
    BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Akun'),
  ];

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(authControllerProvider);

    // Admin gets full dashboard
    if (state.userRole == 'ADMIN') {
      return const AdminDashboardPage();
    }

    final pages = [
      const CatalogPage(),
      const MyOrdersPage(),
      _buildAccountTab(context, ref, state),
    ];

    return Scaffold(
      backgroundColor: AppTheme.cream,
      body: pages[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 20,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (index) => setState(() => _selectedIndex = index),
            items: _bottomItems,
            selectedItemColor: AppTheme.orange,
            unselectedItemColor: AppTheme.grey400,
            backgroundColor: Colors.white,
            type: BottomNavigationBarType.fixed,
            elevation: 0,
            selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
            unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
          ),
        ),
      ),
    );
  }

  Widget _buildAccountTab(BuildContext context, WidgetRef ref, dynamic state) {
    final displayName = state.userFullName?.isNotEmpty == true
        ? state.userFullName
        : state.userEmail ?? 'N/A';
    final hasPhone = state.userPhoneNumber?.isNotEmpty == true;

    return SafeArea(
      bottom: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header: gradient card, gradient-ring avatar, floating camera badge ──
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(22, 26, 22, 24),
              decoration: AppTheme.gradientHeader(radius: 28),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned(
                    top: -40,
                    right: -30,
                    child: Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppTheme.orange.withOpacity(0.16),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => _openEditProfile(context),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Container(
                              width: 72,
                              height: 72,
                              padding: const EdgeInsets.all(3),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [AppTheme.orange, AppTheme.orangeLight],
                                ),
                              ),
                              child: CircleAvatar(
                                backgroundColor: Colors.white.withOpacity(0.15),
                                backgroundImage: state.userProfilePhotoPath != null
                                    ? NetworkImage(
                                        '${ApiConfig.baseUrl}/api/storage/${state.userProfilePhotoPath}',
                                      )
                                    : null,
                                onBackgroundImageError: state.userProfilePhotoPath != null
                                    ? (_, __) {}
                                    : null,
                                child: state.userProfilePhotoPath == null
                                    ? const Icon(Icons.person_rounded, color: Colors.white, size: 32)
                                    : null,
                              ),
                            ),
                            Positioned(
                              bottom: -2,
                              right: -2,
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: AppTheme.navy, width: 2),
                                ),
                                child: const Icon(Icons.camera_alt_rounded, size: 13, color: AppTheme.navy),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              displayName,
                              style: AppTheme.display(size: 18, color: Colors.white),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 3),
                            if (state.userFullName?.isNotEmpty == true)
                              Text(
                                state.userEmail ?? '',
                                style: AppTheme.body(size: 13, color: Colors.white.withOpacity(0.7)),
                                overflow: TextOverflow.ellipsis,
                              ),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.white.withOpacity(0.18)),
                              ),
                              child: Text(
                                (state.userRole ?? 'N/A').toString().toUpperCase(),
                                style: TextStyle(
                                  color: AppTheme.orange,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // ── Menu ──
            AppCard(
              padding: EdgeInsets.zero,
              radius: 22,
              child: Column(
                children: [
                  _buildMenuTile(
                    icon: Icons.edit_rounded,
                    iconColor: AppTheme.info,
                    title: 'Edit Profil',
                    subtitle: 'Ubah nama, foto, dan nomor telepon',
                    onTap: () async {
                      final res = await showDialog<bool>(
                        context: context,
                        builder: (_) => const EditProfileDialog(),
                      );
                      if (!context.mounted) return;
                      if (res == true) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Profil berhasil diperbarui'),
                            behavior: SnackBarBehavior.floating,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        );
                      }
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Divider(height: 1, color: Colors.grey.shade100),
                  ),
                  _buildMenuTile(
                    icon: Icons.chat_bubble_rounded,
                    iconColor: AppTheme.teal,
                    title: 'Bantuan (Chatbot)',
                    subtitle: 'Tanya seputar layanan dan pesanan',
                    onTap: () => Navigator.of(context).pushNamed('/chatbot'),
                  ),
                  if (hasPhone) ...[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Divider(height: 1, color: Colors.grey.shade100),
                    ),
                    _buildMenuTile(
                      icon: Icons.call_rounded,
                      iconColor: AppTheme.orange,
                      title: 'No. Telepon',
                      subtitle: state.userPhoneNumber!,
                      onTap: null,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openEditProfile(BuildContext context) async {
    await showDialog<bool>(context: context, builder: (_) => const EditProfileDialog());
  }

  Widget _buildMenuTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            IconChip(icon: icon, color: iconColor),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: AppTheme.display(size: 14.5, w: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: AppTheme.body(size: 12.5), overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            if (onTap != null)
              Icon(Icons.chevron_right_rounded, color: AppTheme.grey400, size: 22),
          ],
        ),
      ),
    );
  }
}